//
//  main.m
//  UICollectionViewExample
//
//  Created by safil sunny on 26/12/12.
//  Copyright (c) 2012 safil sunny. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SSNAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SSNAppDelegate class]));
    }
}
