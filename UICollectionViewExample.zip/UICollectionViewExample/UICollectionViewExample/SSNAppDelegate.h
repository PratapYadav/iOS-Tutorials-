//
//  SSNAppDelegate.h
//  UICollectionViewExample
//
//  Created by safil sunny on 26/12/12.
//  Copyright (c) 2012 safil sunny. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SSNViewController;

@interface SSNAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) SSNViewController *viewController;

@end
