//
//  SSNViewController.h
//  UICollectionViewExample
//
//  Created by safil sunny on 26/12/12.
//  Copyright (c) 2012 safil sunny. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SSNViewController : UIViewController <UICollectionViewDataSource,UICollectionViewDelegate>{
    IBOutlet UICollectionView *collectionViewPack;

}
@property(nonatomic,retain)IBOutlet UICollectionView *collectionViewPack;
@end
